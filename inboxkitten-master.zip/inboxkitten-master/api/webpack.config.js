module.exports = {
	optimization: {
		// We no not want to minimize our code.
		minimize: false
	}
}