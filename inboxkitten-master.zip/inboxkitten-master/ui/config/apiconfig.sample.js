export default {
	apiUrl: '//${WEBSITE_DOMAIN}/api/v1/mail',
	domain: '${MAILGUN_EMAIL_DOMAIN}'
}
