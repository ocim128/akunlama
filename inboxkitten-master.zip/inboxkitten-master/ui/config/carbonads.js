module.exports = {
	"enable": true,
	"carbon_ad_src": "https://cdn.carbonads.com/carbon.js?serve=CK7D5KQW&placement=inboxkittencom",
	"placement": ["InboxKittenLanding"]
}