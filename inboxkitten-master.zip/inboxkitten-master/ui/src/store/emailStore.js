import config from '@/../config/apiconfig.js'

// State
const state = {
  domain: config.domain,
  apiUrl: config.apiUrl
}

const mutations = {
}

const getters = {}

const actions = {}

export default {
  mutations,
  state,
  getters,
  actions
}
